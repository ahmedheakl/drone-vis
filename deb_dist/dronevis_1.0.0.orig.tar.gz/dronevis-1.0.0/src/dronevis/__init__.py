"""Initializing file containing the version only"""
__version__ = "1.0.0"
