"""Retrieve abstract classes imports"""
from dronevis.abstract.abstract_model import CVModel
