# DroneVis: Full compatible drone library to automate computer vision algorithms on parrot drones.

